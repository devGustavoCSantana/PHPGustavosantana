<?php
    $pageName = "Recuperar Senha de Usuário";
    include("inc/head.inc.php");
?>

<main>
    <h1>Recuperar Senha de Usuário</h1>
    <form method="post" action="../private/api/email-check-recover-password.php">
        <label>Email:</label><br>
        <input type="text" name="user-email" required><br>
        <input type="submit" value="Recuperar Senha">
    </form>
    <hr>
    <p>
        <a href="inde.php">Login</a> |
        <a href="user-registration.php">Cadastro de usuário</a>
    </p>
</main>

<?php
    include("inc/footer.inc.php");
?>