<?php
    $pageName = "Cadastro de Usuário";
    include("inc/head.inc.php");
?>

<main>
    <h1>Cadastro de Usuário</h1>
    <form method="post" action="../private/api/insert-user-registration.php">
        <label>Usuário:</label><br>
        <input type="text" name="user-name" required><br>
        <label>Email:</label><br>
        <input type="text" name="user-email" required><br>
        <label>Senha:</label><br>
        <input type="text" name="user-password" required><br><!-- depois modifica o type para password-->
        <label>Confirmar Senha:</label><br>
        <input type="text" name="user-conf-password" required><br><!-- depois modifica o type para password-->
        <input type="submit" value="Cadastrar">
    </form>
    <hr>
    <p>
        <a href="recover-password-form.php">Recuperar senha</a> | 
        <a href="inde.php">Login</a>
    </p>
</main>

<?php
    include("inc/footer.inc.php");
?>