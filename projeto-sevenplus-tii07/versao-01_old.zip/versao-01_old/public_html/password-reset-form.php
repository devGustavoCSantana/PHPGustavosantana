<?php
    $pageName = "Alterar senha";
    include("inc/head.inc.php");
    
    $idRec = $_GET["idRec"];

    if ((empty($idRec)) || ($idRec === "")) {
        $resp = "ERRO - idRec vazio!";
    } else {
        include("../private/db/conn.php");
        
        $sql = "SELECT email, hash FROM tbuser WHERE hash = '$idRec'";
        $exc = $conn->query($sql);
        $emailDB = "";
        $hashDB = "";

        if ($exc->num_rows > 0) {
            while($row = $exc->fetch_assoc()) {
                $emailDB = $row["email"];
                $hashDB = $row["hash"];
            }

            $conn->close();
        }

        if ($idRec !== $hashDB) {
            $resp = "ERRO - O idRec não combina com a recuperação 
            de senha verifique!";
            $conn->close();
            echo $resp;
        } else {
?>

<main>
    <h1>Alterar senha</h1>
    <form method="post" action="../private/api/update-password-reset.php">
        <input type="hidden" name="idRec" value="<?=$idRec?>">
        <label>Email:</label><br>
        <input type="text" name="user-email" required><br>
        <label>Nova senha:</label><br>
        <input type="text" name="user-password" required><br>
        <label>Repita Nova senha:</label><br>
        <input type="text" name="user-conf-password" required><br>
        <input type="submit" value="Alterar">
    </form>
    <hr>
    <p>
        <a href="inde.php">Login</a> | 
        <a href="user-registration.php">Cadastro de usuário</a>
    </p>
</main>

<?php
        }
    }

    include("inc/footer.inc.php");
?>