<?php
    $pageName = "Cadastro de Usuário";
    include("inc/head.inc.php");
?>

<main>
    <h1>Cadastro de Usuário</h1>
    <h2>Cadastrado com sucesso!</h2>
    <hr>
    <p>
        <a href="#">Recuperar senha</a>
        <a href="inde.php">Login</a>
    </p>
</main>

<?php
    include("inc/footer.inc.php");
?>