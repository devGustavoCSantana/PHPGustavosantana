<?php
    $pageName = "Entre e Curta";
    include("inc/head.inc.php");
?>

<main>
    <h1>Login</h1>
    <form method="post" action="../private/api/validation-user.php">
        <label>Usuário:</label><br>
        <input type="text" name="user-email" required><br>
        <label>Senha:</label><br>
        <input type="text" name="user-password" required><br><!-- depois modifica o type para password-->
        <input type="submit" value="Entre e Curta">
    </form>
    <hr>
    <p>
        <a href="recover-password-form.php">Recuperar senha</a> | 
        <a href="user-registration.php">Cadastro de usuário</a>
    </p>
</main>

<?php
    include("inc/footer.inc.php");
?>