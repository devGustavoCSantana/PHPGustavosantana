<?php
    define("TITLE","SEVENPLUS - Painel Administrativo");
?>