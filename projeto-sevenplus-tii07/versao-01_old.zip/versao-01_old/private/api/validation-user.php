<?php
    $userEmail    = $_POST["user-email"];
    $userPassword = $_POST["user-password"];

    if (((empty($userEmail)) || (empty($userPassword))) || (($userEmail === "") || ($userPassword === ""))) {
        $resp = "ERRO - Campos obrigatórios não preenchidos!";
    } else {
        $apiKey = "maçã";
        $apiKey = (md5($apiKey));
        $pass = (md5($userPassword));
        $loginEmail = (md5($userEmail));
        $passDB = (md5($apiKey.$loginEmail.$pass));
        $valorPass = "09";
        $saltPass = $passDB;
        $passDB = crypt($loginEmail, "$2b$" . $valorPass . "$" . $saltPass . "$");

        include("../db/conn.php");
        $sql = "SELECT * FROM tbuser WHERE (email = '$userEmail' AND idStatus <> 1)";
        $exc = $conn->query($sql);

        $emailDB = "";
        $passwordDB = "";
        $idProfileDB = "";
        $idStatusDB = "";

        if ($exc->num_rows > 0) {
            while($row = $exc->fetch_assoc()) {
                $emailDB = $row["email"];
                $passwordDB = $row["password"];
                $idProfileDB = $row["idProfile"];
                $idStatusDB = $row["idStatus"];
            }
        }

        $conn->close();

        if (!(($userEmail == $emailDB) && ($idStatusDB <> 1) && (crypt($loginEmail, $passDB) === $passwordDB))) {
            $resp = "Usuário não válido!";
        } else {
            $resp = "
                <h2>Bem vindo ao SevenPlus</h2>
                <h3>Curta!!!</h3>
            ";
        }
    }

    echo $resp;
?>