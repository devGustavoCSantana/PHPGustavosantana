<?php
    include("../db/conn.php");
    
    $userEmail = $_POST["user-email"];
    
    $sql = "SELECT email, hash FROM tbuser WHERE email = '$userEmail'";
    $exc = $conn->query($sql);

    if ($exc->num_rows > 0) {
        while ($row = $exc->fetch_assoc()) {
            $email = $row["email"];
            $hash = $row["hash"];
        }

        $url = "http://localhost/projeto-sevenplus-tii07/public_html/password-reset-form.php?idRec=$hash";
        $resp = "
            <h2>Recuperar senha</h2>
            <p>Caro usuário você solicitou a recuperação de senha do SevenPlus?</p>
            <p>Através do email: <b>" . $email . "</b></p>
            <p>Segue o link abaixo para recuperar a senha, clique ou se preferir copie o endereço e cole em seu navegador.</p>
            <p><a href='$url' target='_blank'>$url</a></p>
            <p>Porém caso você não tenha solicitado desconsidere este email</p>
            <h3>Grato equipe SevenPlus!</h3>
        ";
    } else {
        $resp ="O Email não foi encontrado!";
    }

    $conn->close();
    echo $resp;
?>