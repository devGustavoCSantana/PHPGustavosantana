<?php
    $idRec            = $_POST["idRec"];
    $userEmail        = $_POST["user-email"];
    $userPassword     = $_POST["user-password"];
    $userConfPassword = $_POST["user-conf-password"];
    
    if (((empty($userEmail)) || (empty($userPassword)) || (empty($userConfPassword))) || ($userEmail === "") || ($userPassword === "") || ($userConfPassword === "")) {
        $resp = "ERRO - Campos obrigatórios não preenchidos!";
    } else {
        include("../db/conn.php");
        $emailDB = "";
        $hashDB = "";
        $sql = "SELECT * FROM tbuser WHERE email = '$userEmail' AND hash = '$idRec'";
        $exc = $conn->query($sql);
    
        if ($exc->num_rows > 0) {
            while($row = $exc->fetch_assoc()) {
                $idUserDB = $row["idUser"];
                $emailDB = $row["email"];
                $hashDB = $row["hash"];
            }
        }

        if (($userEmail !== $emailDB) && ($idRec !== $hashDB)) {
            $resp = "ERRO - Usuário não registrado!";
            $conn->close();
        } else {
            if ($userPassword !== $userConfPassword) {
                $resp = "ERRO - As senhas não são iguais!";
                $conn->close();
            } else {
                // Criptografia para senha e hash

                // Palavra chave
                $apiKey = "maçã";
                $apiKey = (md5($apiKey));

                $dateTime = new DateTime(null, new DateTimeZone('America/Sao_Paulo'));
                $formattedDate = $dateTime->format('Y-m-d H:i:s');

                $userName = $idRec . $formattedDate;

                $pass = (md5($userPassword));
                $login = (md5($userName));
                $loginEmail = (md5($userEmail));
                
                $passDB = (md5($apiKey.$loginEmail.$pass));
                $passHash = (md5($passDB.$apiKey.$login));

                $valorPass = "09";
                $valorHash = "08";

                $saltPass = $passDB;
                $saltHash = $passHash;

                // Cript Senha - 60 caracteres
                $passDB = crypt($loginEmail, "$2b$" . $valorPass . "$" . $saltPass . "$");
                // Cript Hash - 60 caracteres
                $passHash = crypt($login, "$2b$" . $valorHash . "$" . $saltHash . "$");
                
                // Monta a consulta de atualização
                $sql = "UPDATE tbuser SET password = '$passDB', hash = '$passHash' WHERE idUser = $idUserDB";
                
                if ($conn->query($sql) === TRUE) {
                    $resp = "Senha alterada com sucesso!";
                } else {
                    $resp = "ERRO ao atualizar usuário: " . $conn->error;
                }

                $conn->close();
            }
        }
    }

    echo $resp;
?>