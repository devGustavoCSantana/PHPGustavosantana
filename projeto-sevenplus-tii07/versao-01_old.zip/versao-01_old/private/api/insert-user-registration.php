<?php
    $userName           = $_POST["user-name"];
    $userEmail          = $_POST["user-email"];
    $userPassword       = $_POST["user-password"];
    $userConfPassword   = $_POST["user-conf-password"];

    // Verificar se os campos, foram envidados e não estão vazios
    if (((empty($userName)) || (empty($userEmail)) || (empty($userPassword)) || (empty($userConfPassword))) || ($userName === "") || ($userEmail === "") || ($userPassword === "") || ($userConfPassword === "")) {
        $resp = "ERRO - Campos obrigatórios não preenchidos!";
    } else {
        include("../db/conn.php");
        
        $emailDB = "";

        $sql = "SELECT email FROM tbuser WHERE email = '$userEmail'";
        $exc = $conn->query($sql);

        if ($exc->num_rows > 0) {
            while($row = $exc->fetch_assoc()) {
                $emailDB = $row["email"];
            }
        }
        
        if ($emailDB === $userEmail) {
            $resp = "ERRO - Usuário já registrado!";
        } else {
            // Verificar se as senhas são iguais
            if ($userPassword !== $userConfPassword) {
                $resp = "ERRO - Senhas não são iguais!";
            } else {
                /* Criptografia para senha e hash */
                // Palavra chave
                $apiKey = "maçã";
                $apiKey = (md5($apiKey));
                
                $pass = (md5($userPassword));
                $login = (md5($userName));
                $loginEmail = (md5($userEmail));

                $passDB = (md5($apiKey.$loginEmail.$pass));
                $passHash = (md5($passDB.$apiKey.$login));

                $valorPass = "09";
                $valorHash = "08";

                $saltPass = $passDB;
                $saltHash = $passHash;

                // Cript Senha - 60 caracteres
                $passDB = crypt($loginEmail, "$2b$" . $valorPass . "$" . $saltPass . "$");
                // Cript Hash - 60 caracteres
                $passHash = crypt($login, "$2b$" . $valorHash . "$" . $saltHash . "$");

                // Redirecionar para uma pagina
                //header("Location:../../public_html/user-registration-success.php");
                $idprofile = 1;
                $idstatus = 2;          
                
                // $resp = "<b>Email não cadastrado no banco de dados!</b><br> Email: $userEmail<br> Senha: $passDB<br> Hash: $passHash<br> idProfile: $idprofile<br> idStatus: $idstatus";

                $sql = "INSERT INTO tbuser (iduser, email, password, hash, idprofile, idstatus)
                            VALUES (NULL, '$userEmail', '$passDB', '$passHash', '$idprofile', '$idstatus')
                ";

                $exc = $conn->query($sql);

                if ($exc) {
                    $resp = "Usuário gravado com sucesso!";
                } else {
                    $resp = "Erro ao gravar dados: " . mysqli_error($conn);
                }

                $conn->close();
            }
        }
    }
    
    echo "$resp <br>";
?>